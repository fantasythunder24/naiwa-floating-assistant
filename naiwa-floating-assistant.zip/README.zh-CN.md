# 奶蛙浮窗助手

[English](README.md) · **简体中文**

奶蛙浮窗助手是面向 Windows 上 Codex 桌面端的独立辅助程序。它为当前会话打开一个可置顶、收起和拖动的浮窗，并能把全屏截图贴进会话草稿。

**版本**　`v0.1.0` 预览版，Windows 11 x64。实测环境使用 Windows 版 Codex `26.1120.6357.0`。程序识别 Codex 的简体中文和英文菜单，助手自己的提示和右键菜单目前为简体中文。其他 Codex 版本或显示语言待验证。

## 下载后直接使用

1. 完整解压 Release 页面里的 `Naiwa-Floating-Assistant-v0.1.0-win-x64.zip`。
2. 双击解压目录中的 `bin\NaiwaFloatingAssistant.exe`。
3. 打开或切回 Codex 桌面端，进入一个已有会话。主窗口右上角、窗口控制键左侧会出现抱抽屉的圆形按钮。
4. 点抱抽屉的按钮另开一个浮窗。浮窗默认收起成置顶横条，原会话主窗口可以继续操作。

| 横条上的控件 | 操作 |
| --- | --- |
| 六点手柄 | 按住拖动横条。展开和收起时保留本次拖动的位置。 |
| 抱对话卡片的奶蛙 | 展开或收起聊天。 |
| 拿相机的奶蛙 | 截取横条所在的整块屏幕，打开浮窗并尝试把截图贴进草稿。 |

助手在 Windows 登录会话中独立驻留。Codex 退出时，主窗入口会隐藏，等 Codex 重开后再次显示。右击主窗的圆形按钮，可以选择「退出浮窗助手」。

## 构建和部署

在运行 Codex 的本机 Windows 桌面上，用当前登录账号打开 PowerShell，并切到解压目录或仓库根目录。使用普通用户权限。解压版直接执行部署。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy.ps1
```

需要从源码重新编译时，先运行构建命令，再执行上面的部署命令。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

`build.ps1` 调用 Windows 的 .NET Framework 4.x x64 编译器，生成 `bin\NaiwaFloatingAssistant.exe`。三张 PNG 会嵌入 EXE。`deploy.ps1` 会使用现成的 EXE，缺少 EXE 时先构建，然后复制到 `%LOCALAPPDATA%\NaiwaFloatingAssistant`，校验文件并通过 Windows 资源管理器启动。命令行里的执行策略只应用于本次 PowerShell 进程。

默认手动启动助手。用户要求登录时启动时，运行以下命令，它会创建当前用户的启动快捷方式。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deploy.ps1 -Startup
```

`-NoStart` 可只安装并校验文件。`-InstallDirectory` 可指定另一个安装目录。更新前，先从圆形入口的右键菜单退出旧助手，随后重新部署。若有人还在使用旧版测试助手，同一个 Windows 会话只运行一份。

### 交给 Codex 部署

可以把下面这段发给另一台机器或另一个账号的 Codex。

> 请在当前登录的本机 Windows 桌面上，按 `README.zh-CN.md` 部署奶蛙浮窗助手。先确认 Codex 桌面端和 Windows x64。解压包里有 `bin\NaiwaFloatingAssistant.exe` 时直接执行 `deploy.ps1`，源码目录则先运行 `build.ps1`。使用默认安装路径，开机启动仅在我明确要求时添加。启动后检查助手进程和 Codex 主窗口的圆形入口，再按下方步骤验证浮窗。尽量使用专门的测试会话和无敏感内容的桌面，避免改动已有聊天草稿。报告实际验收结果和仍待验证的项目。

### 部署验收

1. `Get-Process NaiwaFloatingAssistant` 能查到助手。切回桌面端 Codex 的会话，确认右上角显示抱抽屉的圆形入口。
2. 点入口，确认新增一个置顶横条，主窗口继续可用。拖动横条，再展开、收起，检查横条仍在所选位置。
3. 在测试会话点相机，确认截图作为一张图片出现在浮窗草稿中。检查输入框焦点，测试图可在草稿中移除。
4. 若草稿里没有图片，检查剪贴板并尝试在输入框按 `Ctrl+V`。若没有圆形入口，先确认助手在本机交互式 Windows 桌面会话中运行，再切到前台 Codex 的一个已有聊天。

## 截图和临时文件

点相机时，助手在内存中生成截图，将其放进 Windows 剪贴板，再尝试按 `Ctrl+V` 粘贴到浮窗草稿。发送由你在 Codex 里确认。Codex 处理粘贴的图片时可能写出 `%TEMP%\codex-clipboard-*.png`，清理时间由 Windows 和 Codex 的临时文件策略决定。

## 退出和卸载

先右击主窗口的圆形入口，选「退出浮窗助手」。若使用过 `-Startup`，在文件资源管理器打开 `shell:startup`，移除 `Naiwa Floating Assistant.lnk`。用部署脚本安装时，程序位于安装输出显示的目录；直接运行 ZIP 中的版本时，程序在解压目录的 `bin` 下。

## 源码和 GitHub 发布

- `src/` 是窗口、截图和按钮绘制代码。
- `assets/` 是置顶浮窗、聊天开关和截图三个按钮的原图。
- `build.ps1` 和 `deploy.ps1` 用于构建和本机部署。`pack.ps1` 重新构建并生成包含两份说明的发布 ZIP，也可加 `-UseExistingBinary` 使用已有的 `bin\NaiwaFloatingAssistant.exe`。
- `bin/` 和 `release/` 是本地构建与发布文件，已配置 Git 忽略。对外提供时，把准备好的 ZIP 作为 GitHub Release 附件上传。
