# Builds the x64 desktop helper using the Windows .NET Framework compiler.
$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) {
    throw 'Build on 64-bit Windows.'
}

$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) {
    throw "The .NET Framework compiler was not found at $compiler. Enable or repair .NET Framework 4.x on Windows."
}

$references = foreach ($relativePath in @(
    'System.Windows.Forms.dll', 'System.Drawing.dll', 'Accessibility.dll',
    'WPF\UIAutomationClient.dll', 'WPF\UIAutomationTypes.dll', 'WPF\WindowsBase.dll'
)) {
    $path = Join-Path $framework $relativePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing Windows framework assembly: $path" }
    "/reference:$path"
}

$resources = foreach ($name in @('pin.png', 'chat.png', 'capture.png')) {
    $path = Join-Path $PSScriptRoot "assets\$name"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing icon: $path" }
    "/resource:$path,CodexFloat.$name"
}

$sources = @('CodexScreenshot.cs', 'FloatingChatLauncher.cs', 'RoundImageButton.cs') | ForEach-Object {
    Join-Path $PSScriptRoot "src\$_"
}
$manifest = Join-Path $PSScriptRoot 'src\CodexScreenshot.manifest'
$outputDirectory = Join-Path $PSScriptRoot 'bin'
$null = New-Item -ItemType Directory -Path $outputDirectory -Force
$exe = Join-Path $outputDirectory 'NaiwaFloatingAssistant.exe'

& $compiler /nologo /target:winexe /platform:x64 /optimize+ /codepage:65001 "/win32manifest:$manifest" "/out:$exe" @references @resources @sources
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) {
    throw 'Build failed. If the executable in bin is running, exit it and build again.'
}
Write-Output $exe
