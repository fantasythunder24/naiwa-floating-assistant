param(
    [switch]$Startup,
    [switch]$NoStart,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'NaiwaFloatingAssistant')
)

$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) {
    throw 'Deploy on 64-bit Windows.'
}

$name = 'NaiwaFloatingAssistant.exe'
$source = Join-Path $PSScriptRoot "bin\$name"
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { & (Join-Path $PSScriptRoot 'build.ps1') | Out-Null }

$directory = [IO.Path]::GetFullPath($InstallDirectory)
$null = New-Item -ItemType Directory -Path $directory -Force
$destination = Join-Path $directory $name
$sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$installed = Test-Path -LiteralPath $destination -PathType Leaf
$needsCopy = -not $installed -or (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $sourceHash
if ($needsCopy) {
    $staged = Join-Path $directory ('.' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        Copy-Item -LiteralPath $source -Destination $staged
        if ($installed) { [IO.File]::Replace($staged, $destination, [NullString]::Value) }
        else { [IO.File]::Move($staged, $destination) }
    } catch {
        throw "Unable to install $destination. Exit any copy running from that path and retry. $($_.Exception.Message)"
    } finally {
        if (Test-Path -LiteralPath $staged -PathType Leaf) { Remove-Item -LiteralPath $staged }
    }
}
if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $sourceHash) {
    throw "Installed executable verification failed: $destination"
}
Write-Host "Installed: $destination"

if ($Startup) {
    $startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
    $linkPath = Join-Path $startup 'Naiwa Floating Assistant.lnk'
    $wsh = New-Object -ComObject WScript.Shell
    $link = $wsh.CreateShortcut($linkPath)
    if ((Test-Path -LiteralPath $linkPath) -and $link.TargetPath -and $link.TargetPath -ne $destination) {
        throw "A different Startup shortcut already uses this name: $linkPath"
    }
    $link.TargetPath = $destination
    $link.WorkingDirectory = $directory
    $link.Description = 'Naiwa Floating Assistant for Codex on Windows'
    $link.Save()
    Write-Host "Startup shortcut: $linkPath"
}

if (-not $NoStart) {
    $running = @(Get-Process -Name 'NaiwaFloatingAssistant' -ErrorAction SilentlyContinue)
    if ($running | Where-Object { $_.Path -eq $destination }) {
        Write-Host 'The installed helper is already running.'
        return
    }
    try {
        $mutex = [Threading.Mutex]::OpenExisting('Local\CodexScreenshotButton')
        $mutex.Dispose()
        throw 'A floating assistant is already active in this Windows session. Exit it before starting this copy.'
    } catch [Threading.WaitHandleCannotBeOpenedException] { }

    $shell = New-Object -ComObject Shell.Application
    [int]$desktopHandle = 0
    $desktop = $shell.Windows().FindWindowSW(0, $null, 8, [ref]$desktopHandle, 1)
    if (-not $desktop) {
        throw "No interactive Explorer desktop was found. Open $destination from File Explorer in your Windows session."
    }
    $desktop.Document.Application.ShellExecute($destination, '', $directory, 'open', 1)
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Milliseconds 100
        if (Get-Process -Name 'NaiwaFloatingAssistant' -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $destination }) {
            Write-Host 'The installed helper is running.'
            return
        }
    }
    throw "Explorer did not leave the helper running. Open $destination from File Explorer and check for a launch error."
}
