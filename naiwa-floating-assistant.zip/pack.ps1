# Builds and writes the single ZIP used for a GitHub Release.
param([switch]$UseExistingBinary)

$ErrorActionPreference = 'Stop'
$exe = Join-Path $PSScriptRoot 'bin\NaiwaFloatingAssistant.exe'
if (-not $UseExistingBinary) { $exe = & (Join-Path $PSScriptRoot 'build.ps1') }
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'The executable is missing. Run build.ps1 first.' }
$version = [version](Get-Item -LiteralPath $exe).VersionInfo.FileVersion
$packageName = 'Naiwa-Floating-Assistant-v{0}-win-x64' -f $version.ToString(3)
$release = Join-Path $PSScriptRoot 'release'
$null = New-Item -ItemType Directory -Path $release -Force
$zip = Join-Path $release "$packageName.zip"
$temporaryZip = Join-Path $release ('.' + [guid]::NewGuid().ToString('N') + '.zip')
$archiveTimestamp = [DateTimeOffset]::new(2000, 1, 1, 0, 0, 0, [TimeSpan]::Zero)

Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$files = @(
    '.gitignore', 'LICENSE', 'README.md', 'README.zh-CN.md', 'build.ps1', 'deploy.ps1', 'pack.ps1',
    'src/CodexScreenshot.cs', 'src/FloatingChatLauncher.cs', 'src/RoundImageButton.cs', 'src/CodexScreenshot.manifest',
    'assets/pin.png', 'assets/chat.png', 'assets/capture.png', 'bin/NaiwaFloatingAssistant.exe'
)

try {
    $archive = [IO.Compression.ZipFile]::Open($temporaryZip, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in $files) {
            $path = Join-Path $PSScriptRoot ($file.Replace('/', '\'))
            $entry = $archive.CreateEntry("$packageName/$file", [IO.Compression.CompressionLevel]::Optimal)
            $entry.LastWriteTime = $archiveTimestamp
            $inputFile = [IO.File]::OpenRead($path)
            try {
                $entryStream = $entry.Open()
                try { $inputFile.CopyTo($entryStream) }
                finally { $entryStream.Dispose() }
            } finally { $inputFile.Dispose() }
        }
    } finally { $archive.Dispose() }

    if (Test-Path -LiteralPath $zip -PathType Leaf) { [IO.File]::Replace($temporaryZip, $zip, [NullString]::Value) }
    else { [IO.File]::Move($temporaryZip, $zip) }
} finally {
    if (Test-Path -LiteralPath $temporaryZip -PathType Leaf) { Remove-Item -LiteralPath $temporaryZip }
}
Write-Output $zip
