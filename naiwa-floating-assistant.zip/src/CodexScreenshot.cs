using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Forms;

[assembly: AssemblyTitle("奶蛙浮窗助手")]
[assembly: AssemblyProduct("奶蛙浮窗助手")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        bool firstInstance;
        using (var mutex = new Mutex(true, "Local\\CodexScreenshotButton", out firstInstance))
        {
            if (!firstInstance) return;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (var desktop = new FloatingChatApplication())
                Application.Run(desktop);
        }
    }
}

internal sealed class ScreenshotDock : Form
{
    internal const int HeightInDips = 56;
    private const int WidthInDips = 136;
    private const int ButtonInDips = 48;
    private const string IdleLabel = "截全屏";
    private readonly IntPtr target;
    private readonly int collapsedTopInset;
    private readonly Panel grip;
    private readonly RoundImageButton capture;
    private readonly RoundImageButton toggleChat;
    private readonly ToolTip tip;
    private readonly System.Windows.Forms.Timer followTimer;
    private DateTime resetStatus;
    private DateTime confirmInitialCollapseUntil;
    private Point? manualDockLocation;
    private Point dragStartPointer;
    private Point dragStartWindow;
    private bool dragging;
    private bool working;

    internal event Action CaptureStarting;

    internal ScreenshotDock(IntPtr target, int collapsedTopInset)
    {
        this.target = target;
        this.collapsedTopInset = collapsedTopInset;
        Text = "Codex 截图按钮";
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.FromArgb(22, 37, 46);

        grip = MakeDragGrip();
        toggleChat = new RoundImageButton("展开聊天", "chat.png");
        capture = new RoundImageButton(IdleLabel, "capture.png");
        Controls.AddRange(new Control[] { grip, toggleChat, capture });

        tip = new ToolTip();
        tip.SetToolTip(grip, "按住拖动横条");
        tip.SetToolTip(toggleChat, "展开聊天");
        tip.SetToolTip(capture, "截取这块屏幕并把图片插入当前聊天的草稿");
        var menu = new ContextMenuStrip();
        var transparency = new ToolStripMenuItem("展开时半透明（50%）") { CheckOnClick = true };
        transparency.Click += delegate
        {
            if (Native.SetOpacity(target, transparency.Checked ? (byte)128 : (byte)255)) return;
            transparency.Checked = !transparency.Checked;
            tip.Show("暂时无法切换聊天窗口的透明度。", toggleChat, 0, toggleChat.Height + 2, 3200);
        };
        menu.Items.Add(transparency);
        menu.Items.Add("退出横条", null, (sender, args) => Close());
        grip.ContextMenuStrip = menu;
        toggleChat.ContextMenuStrip = menu;
        capture.ContextMenuStrip = menu;
        toggleChat.Click += delegate
        {
            confirmInitialCollapseUntil = DateTime.MinValue;
            if (Native.IsIconic(target)) RestoreChat();
            else Native.ShowWindow(target, Native.SwMinimize);
            FollowTarget();
        };
        capture.Click += CaptureClick;

        followTimer = new System.Windows.Forms.Timer { Interval = 150 };
        followTimer.Tick += delegate { FollowTarget(); };
        Shown += delegate { FollowTarget(); followTimer.Start(); };
        FormClosing += delegate { RestoreChat(); };
        FormClosed += delegate { followTimer.Dispose(); tip.Dispose(); menu.Dispose(); };
        Bounds = DockBounds(true);
        Native.PinWindow(target);
        Native.SetOpacity(target, 255);
        confirmInitialCollapseUntil = DateTime.UtcNow.AddSeconds(1);
        Native.ShowWindow(target, Native.SwMinimize);
    }

    private Panel MakeDragGrip()
    {
        var grip = new Panel
        {
            BackColor = BackColor,
            Cursor = Cursors.SizeAll,
            AccessibleName = "拖动横条",
            AccessibleRole = AccessibleRole.Grip,
            TabStop = false,
        };
        grip.Paint += delegate(object sender, PaintEventArgs args)
        {
            var dot = Math.Max(2, grip.Width / 10);
            var left = (grip.Width - 3 * dot) / 2;
            var top = (grip.Height - 5 * dot) / 2;
            args.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using (var brush = new SolidBrush(Color.FromArgb(163, 184, 185)))
            {
                for (int row = 0; row < 3; row++)
                {
                    int y = top + row * 2 * dot;
                    args.Graphics.FillEllipse(brush, left, y, dot, dot);
                    args.Graphics.FillEllipse(brush, left + 2 * dot, y, dot, dot);
                }
            }
        };
        grip.MouseDown += delegate(object sender, MouseEventArgs args)
        {
            if (args.Button != MouseButtons.Left || working) return;
            dragStartPointer = grip.PointToScreen(args.Location);
            dragStartWindow = Location;
            dragging = true;
            grip.Capture = true;
        };
        grip.MouseMove += delegate
        {
            if (dragging && grip.Capture) MoveDraggedDock(Cursor.Position);
        };
        grip.MouseUp += delegate(object sender, MouseEventArgs args)
        {
            if (args.Button != MouseButtons.Left) return;
            if (dragging && grip.Capture) MoveDraggedDock(grip.PointToScreen(args.Location));
            dragging = false;
            grip.Capture = false;
            FollowTarget();
        };
        grip.MouseCaptureChanged += delegate { if (!grip.Capture) dragging = false; };
        return grip;
    }

    private void MoveDraggedDock(Point pointer)
    {
        var desired = new Point(dragStartWindow.X + pointer.X - dragStartPointer.X,
            dragStartWindow.Y + pointer.Y - dragStartPointer.Y);
        var next = KeepOnScreen(new Rectangle(desired, Size), Screen.FromPoint(pointer).WorkingArea);
        if (next.Location == Location) return;
        manualDockLocation = next.Location;
        Location = next.Location;
    }

    protected override void OnSizeChanged(EventArgs args)
    {
        base.OnSizeChanged(args);
        RoundedWindow.ApplyRegion(this, ClientSize.Height / 2);
        if (grip == null || toggleChat == null || capture == null) return;
        var scale = Math.Min(ClientSize.Width / (double)WidthInDips, ClientSize.Height / (double)HeightInDips);
        var diameter = (int)Math.Round(ButtonInDips * scale);
        var x = (ClientSize.Width - (int)Math.Round(WidthInDips * scale)) / 2;
        var y = (ClientSize.Height - diameter) / 2;
        grip.SetBounds(x + (int)Math.Round(5 * scale), y, (int)Math.Round(23 * scale), diameter);
        toggleChat.SetBounds(x + (int)Math.Round(31 * scale), y, diameter, diameter);
        capture.SetBounds(x + (int)Math.Round(83 * scale), y, diameter, diameter);
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    protected override CreateParams CreateParams
    {
        get
        {
            var parameters = base.CreateParams;
            parameters.ExStyle |= 0x08000000 | 0x00000080; // WS_EX_NOACTIVATE and WS_EX_TOOLWINDOW
            return parameters;
        }
    }

    private Rectangle DockBounds(bool collapsed)
    {
        var monitor = manualDockLocation.HasValue ? Screen.FromPoint(manualDockLocation.Value) : Screen.FromHandle(target);
        var screen = monitor.WorkingArea;
        var dpiWindow = manualDockLocation.HasValue && IsHandleCreated ? Handle : target;
        var dpi = Math.Max(96u, Native.GetDpiForWindow(dpiWindow));
        int width = (int)Math.Round(WidthInDips * dpi / 96.0);
        int height = (int)Math.Round(HeightInDips * dpi / 96.0);
        if (manualDockLocation.HasValue)
            return KeepOnScreen(new Rectangle(manualDockLocation.Value, new Size(width, height)), screen);

        int gap = (int)Math.Round(6 * dpi / 96.0);
        int screenMargin = gap * 2;
        Native.Rect rect;
        if (collapsed || !Native.GetWindowRect(target, out rect))
        {
            int top = (int)Math.Round(collapsedTopInset * dpi / 96.0);
            return KeepOnScreen(new Rectangle(screen.Right - width - screenMargin, screen.Top + top, width, height), screen);
        }

        int x = rect.Right - width - gap;
        int y = rect.Top - height - gap;
        if (y < screen.Top)
        {
            if (rect.Right + width + gap <= screen.Right)
            {
                x = rect.Right + gap;
                y = rect.Top + gap;
            }
            else if (rect.Left - width - gap >= screen.Left)
            {
                x = rect.Left - width - gap;
                y = rect.Top + gap;
            }
            else
            {
                y = rect.Bottom + gap <= screen.Bottom - height
                    ? rect.Bottom + gap : rect.Top + height + gap;
            }
        }

        return KeepOnScreen(new Rectangle(x, y, width, height), screen);
    }

    private static Rectangle KeepOnScreen(Rectangle bounds, Rectangle screen)
    {
        int width = Math.Min(bounds.Width, screen.Width);
        int height = Math.Min(bounds.Height, screen.Height);
        int x = Math.Max(screen.Left, Math.Min(bounds.X, screen.Right - width));
        int y = Math.Max(screen.Top, Math.Min(bounds.Y, screen.Bottom - height));
        return new Rectangle(x, y, width, height);
    }

    private void FollowTarget()
    {
        if (working) return;
        if (!Native.IsWindow(target))
        {
            Close();
            return;
        }

        if (!Native.IsPinned(target)) Native.PinWindow(target);
        if (DateTime.UtcNow < confirmInitialCollapseUntil && !Native.IsIconic(target))
            Native.ShowWindow(target, Native.SwMinimize);
        bool collapsed = Native.IsIconic(target);
        if (!Native.IsWindowVisible(target) && !collapsed)
        {
            if (Visible) Hide();
            return;
        }

        if (!dragging)
        {
            var bounds = DockBounds(collapsed);
            if (Bounds != bounds) Bounds = bounds;
        }
        var toggleLabel = collapsed ? "展开聊天" : "收起聊天";
        if (toggleChat.Text != toggleLabel)
        {
            toggleChat.Text = toggleLabel;
            toggleChat.AccessibleName = toggleLabel;
            toggleChat.Accent = collapsed ? (Color?)null : Color.FromArgb(205, 228, 177);
            tip.SetToolTip(toggleChat, toggleLabel);
        }
        if (!Visible) Show();
        Native.Rect targetBounds;
        if (!collapsed && Native.GetWindowRect(target, out targetBounds) &&
            Bounds.IntersectsWith(Rectangle.FromLTRB(targetBounds.Left, targetBounds.Top, targetBounds.Right, targetBounds.Bottom)))
            Native.KeepOverlayAbove(Handle, target);
        if (capture.Text != IdleLabel && DateTime.UtcNow >= resetStatus)
        {
            capture.Text = IdleLabel;
            capture.Accent = null;
        }
    }

    private void RestoreChat()
    {
        if (Native.IsWindow(target) && Native.IsIconic(target))
            Native.ShowWindow(target, Native.SwRestore);
    }

    internal void OpenChat()
    {
        confirmInitialCollapseUntil = DateTime.MinValue;
        RestoreChat();
        Native.SetForegroundWindow(target);
        FollowTarget();
    }

    private void CaptureClick(object sender, EventArgs args)
    {
        if (working || (!Native.IsWindowVisible(target) && !Native.IsIconic(target))) return;
        confirmInitialCollapseUntil = DateTime.MinValue;
        working = true;
        bool clipboardReady = false;
        string label;
        string detail;

        try
        {
            var starting = CaptureStarting;
            if (starting != null) starting();
            uint screenshotClipboardVersion;
            using (var image = TakeScreenshot())
            {
                CopyToClipboard(image);
                screenshotClipboardVersion = Native.GetClipboardSequenceNumber();
                clipboardReady = true;
            }

            RestoreChat();
            if (ChatWindow.FocusComposerAndPaste(target, screenshotClipboardVersion))
            {
                label = "已贴图";
                detail = "截图已贴到当前聊天的草稿，可以继续输入。";
            }
            else if (Native.GetClipboardSequenceNumber() == screenshotClipboardVersion)
            {
                label = "已复制";
                detail = "截图在剪贴板里。点聊天输入框，按 Ctrl+V 粘贴。";
            }
            else
            {
                label = "请重试";
                detail = "剪贴板内容已更改，点击重新截图。";
            }
        }
        catch (Exception ex)
        {
            if (!(ex is ExternalException || ex is InvalidOperationException || ex is System.ComponentModel.Win32Exception)) throw;
            label = clipboardReady ? "已复制" : "请重试";
            detail = clipboardReady ? "截图在剪贴板里，请按 Ctrl+V 粘贴。" : "截图或复制没有完成，点击重试。";
        }
        finally
        {
            working = false;
            FollowTarget();
        }

        if (IsDisposed) return;
        capture.Text = label;
        capture.Accent = label == "已贴图" ? Color.FromArgb(154, 226, 177) :
            label == "已复制" ? Color.FromArgb(255, 210, 133) : Color.FromArgb(251, 154, 141);
        resetStatus = DateTime.UtcNow.AddSeconds(2);
        if (label != "已贴图") tip.Show(detail, capture, 0, capture.Height + 2, 4000);
    }

    private Bitmap TakeScreenshot()
    {
        var monitor = Screen.FromRectangle(Bounds).Bounds;
        var wasCollapsed = Native.IsIconic(target);
        Hide();
        if (!wasCollapsed) Native.ShowWindow(target, Native.SwHide);
        try
        {
            Native.DwmFlush();
            Thread.Sleep(85);
            if ((Native.IsWindowVisible(target) && !Native.IsIconic(target)) || Native.IsWindowVisible(Handle))
                throw new InvalidOperationException("The chat or the button is still visible.");

            return Native.Capture(monitor);
        }
        finally
        {
            if (!wasCollapsed && Native.IsWindow(target)) Native.ShowWindow(target, Native.SwShowNoActivate);
        }
    }

    private static void CopyToClipboard(Bitmap image)
    {
        using (var png = new MemoryStream())
        {
            image.Save(png, ImageFormat.Png);
            png.Position = 0;
            var contents = new DataObject();
            contents.SetImage(image);
            contents.SetData("PNG", false, png);
            Clipboard.SetDataObject(contents, true, 8, 45);
        }
    }
}

internal static class ChatWindow
{
    internal static bool HasComposer(IntPtr window)
    {
        return GetComposer(window) != null;
    }

    internal static string GetChatTitle(IntPtr window)
    {
        try
        {
            var root = AutomationElement.FromHandle(window);
            var toolbar = FindByName(root, new[] { "聊天工具栏", "Chat toolbar", "Conversation toolbar" });
            if (toolbar == null) return null;
            var text = new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Text);
            foreach (AutomationElement element in toolbar.FindAll(TreeScope.Descendants, text))
            {
                var title = element.Current.Name;
                if (!string.IsNullOrWhiteSpace(title) && title != "新聊天" &&
                    !title.Equals("New chat", StringComparison.OrdinalIgnoreCase)) return title;
            }
        }
        catch (ElementNotAvailableException) { }
        catch (InvalidOperationException) { }
        catch (ArgumentException) { }
        catch (COMException) { }
        return null;
    }

    internal static IntPtr[] Windows()
    {
        var windows = new List<IntPtr>();
        Native.EnumWindows(delegate(IntPtr window, IntPtr data)
        {
            if (Native.IsWindowVisible(window) && IsCodexWindow(window)) windows.Add(window);
            return true;
        }, IntPtr.Zero);
        return windows.ToArray();
    }

    internal static bool OpenInNewWindow(IntPtr main)
    {
        if (!IsAvailable(main) || Native.GetForegroundWindow() != main) return false;
        var root = AutomationElement.FromHandle(main);
        var chatMenu = FindByName(root, new[] { "聊天操作", "Chat actions" });
        if (chatMenu != null)
            return InvokeMenuItem(main, chatMenu, new[] { "在新窗口中打开", "Open in new window" });
        var fileMenu = FindByName(root, new[] { "文件", "File" });
        return InvokeMenuItem(main, fileMenu, new[] { "新建窗口", "新窗口", "New Window" });
    }

    private static bool InvokeMenuItem(IntPtr window, AutomationElement menu, string[] actionNames)
    {
        object pattern;
        if (menu == null || menu.Current.IsOffscreen ||
            !menu.TryGetCurrentPattern(ExpandCollapsePattern.Pattern, out pattern)) return false;
        if (menu.Current.IsKeyboardFocusable && Native.GetForegroundWindow() == window) menu.SetFocus();
        var dropdown = (ExpandCollapsePattern)pattern;
        var menuItemType = new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.MenuItem);
        for (int attempt = 0; attempt < 24; attempt++)
        {
            if (attempt % 8 == 0)
            {
                var state = dropdown.Current.ExpandCollapseState;
                if (attempt > 0 && state == ExpandCollapseState.Expanded)
                {
                    dropdown.Collapse();
                    Thread.Sleep(100);
                }
                if (dropdown.Current.ExpandCollapseState == ExpandCollapseState.Collapsed) dropdown.Expand();
            }
            var root = AutomationElement.FromHandle(window);
            var items = root.FindAll(TreeScope.Descendants, menuItemType);
            foreach (AutomationElement item in items)
            {
                var state = item.Current;
                if (state.IsOffscreen || !state.IsEnabled || !actionNames.Contains(state.Name, StringComparer.OrdinalIgnoreCase)) continue;
                if (item.TryGetCurrentPattern(InvokePattern.Pattern, out pattern))
                {
                    ((InvokePattern)pattern).Invoke();
                    return true;
                }
            }
            Thread.Sleep(50);
        }
        if (dropdown.Current.ExpandCollapseState == ExpandCollapseState.Expanded) dropdown.Collapse();
        return false;
    }

    private static AutomationElement FindByName(AutomationElement root, string[] names)
    {
        var clauses = names.Select(name => (Condition)new PropertyCondition(AutomationElement.NameProperty,
            name, PropertyConditionFlags.IgnoreCase)).ToArray();
        return root.FindFirst(TreeScope.Descendants, new OrCondition(clauses));
    }

    internal static bool FocusComposerAndPaste(IntPtr window, uint clipboardVersion)
    {
        if (!IsAvailable(window)) return false;
        Native.SetForegroundWindow(window);
        for (int attempt = 0; attempt < 8; attempt++)
        {
            if (Native.GetForegroundWindow() == window) break;
            Thread.Sleep(30);
        }
        if (Native.GetForegroundWindow() != window) return false;

        var composer = GetComposer(window);
        if (composer == null) return false;
        try
        {
            composer.SetFocus();
            bool focused = false;
            for (int attempt = 0; attempt < 8; attempt++)
            {
                var current = AutomationElement.FocusedElement;
                if (current != null && composer.Equals(current))
                {
                    focused = true;
                    break;
                }
                Thread.Sleep(30);
            }
            return focused && Native.GetForegroundWindow() == window &&
                Native.GetClipboardSequenceNumber() == clipboardVersion && Native.Paste();
        }
        catch (ElementNotAvailableException) { return false; }
        catch (InvalidOperationException) { return false; }
    }

    private static bool IsAvailable(IntPtr window)
    {
        return Native.IsWindowVisible(window) && !Native.IsIconic(window) && IsCodexWindow(window);
    }

    internal static bool IsCodexWindow(IntPtr window)
    {
        if (!Native.IsWindow(window)) return false;
        var name = new StringBuilder(64);
        Native.GetClassName(window, name, name.Capacity);
        if (name.ToString() != "Chrome_WidgetWin_1") return false;
        uint pid;
        Native.GetWindowThreadProcessId(window, out pid);
        try
        {
            using (var process = Process.GetProcessById((int)pid))
            {
                return process.ProcessName.Equals("ChatGPT", StringComparison.OrdinalIgnoreCase)
                    || process.ProcessName.Equals("Codex", StringComparison.OrdinalIgnoreCase);
            }
        }
        catch (ArgumentException) { return false; }
    }

    private static AutomationElement GetComposer(IntPtr window)
    {
        try
        {
            var root = AutomationElement.FromHandle(window);
            var condition = new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit);
            var editors = root.FindAll(TreeScope.Descendants, condition);
            var matches = new List<AutomationElement>();
            foreach (AutomationElement editor in editors)
            {
                var info = editor.Current;
                if (info.IsOffscreen || !info.IsEnabled || !info.IsKeyboardFocusable ||
                    !info.ClassName.StartsWith("ProseMirror", StringComparison.Ordinal)) continue;

                var parent = TreeWalker.RawViewWalker.GetParent(editor);
                if (parent != null && parent.Current.ClassName.StartsWith("ComposerLayoutBody", StringComparison.Ordinal))
                    matches.Add(editor);
            }
            return matches.Count == 1 ? matches[0] : null;
        }
        catch (ElementNotAvailableException) { return null; }
        catch (InvalidOperationException) { return null; }
        catch (ArgumentException) { return null; }
    }
}


internal static class Native
{
    internal const int SwHide = 0;
    internal const int SwMinimize = 6;
    internal const int SwShowNoActivate = 8;
    internal const int SwRestore = 9;
    private const int ExtendedStyle = -20;
    private const int Layered = 0x00080000;
    private const uint UseAlpha = 2;

    [StructLayout(LayoutKind.Sequential)]
    public struct Rect { public int Left, Top, Right, Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    private struct KeyInput
    {
        public ushort VirtualKey, ScanCode;
        public uint Flags, Time;
        public IntPtr ExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MouseInput
    {
        public int X, Y;
        public uint Data, Flags, Time;
        public IntPtr ExtraInfo;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputData
    {
        [FieldOffset(0)] public KeyInput Key;
        [FieldOffset(0)] public MouseInput Mouse;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct Input { public uint Type; public InputData Data; }

    public delegate bool WindowCallback(IntPtr window, IntPtr data);

    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr window);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr window);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr window, int command);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr window, out Rect rect);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr window, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongW")] private static extern int SetWindowLong(IntPtr window, int index, int style);
    [DllImport("user32.dll")] private static extern bool GetLayeredWindowAttributes(IntPtr window, out uint colorKey, out byte alpha, out uint flags);
    [DllImport("user32.dll")] private static extern bool SetLayeredWindowAttributes(IntPtr window, uint colorKey, byte alpha, uint flags);
    [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr window);
    [DllImport("user32.dll")] public static extern bool EnumWindows(WindowCallback callback, IntPtr data);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetClipboardSequenceNumber();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr window, StringBuilder name, int length);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int virtualKey);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, Input[] inputs, int size);
    [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr window);
    [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr window, IntPtr context);
    [DllImport("gdi32.dll", SetLastError = true)] private static extern bool BitBlt(IntPtr destination, int x, int y, int width, int height,
        IntPtr source, int sourceX, int sourceY, uint operation);
    [DllImport("dwmapi.dll")] public static extern int DwmFlush();
    [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr window, int attribute, out Rect rect, int size);

    internal static bool GetVisibleBounds(IntPtr window, out Rect rect)
    {
        return DwmGetWindowAttribute(window, 9, out rect, Marshal.SizeOf(typeof(Rect))) == 0 || GetWindowRect(window, out rect);
    }

    internal static void PlaceFloatingWindow(IntPtr window, IntPtr main, int collapsedTopInset)
    {
        if (window == main || !IsWindow(window)) return;
        if (IsZoomed(window)) ShowWindow(window, SwRestore);
        var area = Screen.FromHandle(main).WorkingArea;
        double scale = Math.Max(96u, GetDpiForWindow(main)) / 96.0;
        int margin = (int)Math.Round(6 * scale);
        int top = (int)Math.Round((collapsedTopInset + ScreenshotDock.HeightInDips + 6) * scale);
        int width = Math.Min((int)Math.Round(480 * scale), area.Width - 2 * margin);
        int height = Math.Min((int)Math.Round(600 * scale), area.Height - top - margin);
        SetWindowPos(window, new IntPtr(-1), area.Right - width - margin, area.Top + top, width, height, 0x0210);
    }

    internal static bool IsPinned(IntPtr window)
    {
        return (GetWindowLong(window, ExtendedStyle) & 0x00000008) != 0;
    }

    internal static void PinWindow(IntPtr window)
    {
        SetWindowPos(window, new IntPtr(-1), 0, 0, 0, 0, 0x0213); // Keep geometry, focus, and owner window order.
    }

    internal static void KeepOverlayAbove(IntPtr overlay, IntPtr target)
    {
        bool targetIsAbove = false;
        EnumWindows(delegate(IntPtr window, IntPtr data)
        {
            if (window == overlay) return false;
            if (window != target) return true;
            targetIsAbove = true;
            return false;
        }, IntPtr.Zero);
        if (targetIsAbove) PinWindow(overlay);
    }

    internal static bool SetOpacity(IntPtr window, byte alpha)
    {
        int style = GetWindowLong(window, ExtendedStyle);
        bool alreadyLayered = (style & Layered) != 0;
        uint colorKey = 0;
        uint flags = 0;
        byte existingAlpha;
        if (alreadyLayered)
        {
            if (!GetLayeredWindowAttributes(window, out colorKey, out existingAlpha, out flags)) return false;
        }
        else
        {
            if (alpha == 255) return true;
            SetWindowLong(window, ExtendedStyle, style | Layered);
        }

        if (SetLayeredWindowAttributes(window, colorKey, alpha, flags | UseAlpha)) return true;
        if (!alreadyLayered) SetWindowLong(window, ExtendedStyle, style);
        return false;
    }

    internal static bool Paste()
    {
        const ushort control = 0x11;
        const ushort v = 0x56;
        int[] modifiers = { 0x10, control, 0x12, 0x5B, 0x5C };
        if (modifiers.Any(key => (GetAsyncKeyState(key) & 0x8000) != 0)) return false;

        Input[] keys = { Key(control, false), Key(v, false), Key(v, true), Key(control, true) };
        uint sent = SendInput((uint)keys.Length, keys, Marshal.SizeOf(typeof(Input)));
        if (sent == keys.Length) return true;
        if (sent != 0) SendInput(2, new[] { Key(v, true), Key(control, true) }, Marshal.SizeOf(typeof(Input)));
        return false;
    }

    private static Input Key(ushort code, bool release)
    {
        return new Input { Type = 1, Data = new InputData { Key = new KeyInput { VirtualKey = code, Flags = release ? 2u : 0u } } };
    }

    internal static Bitmap Capture(Rectangle area)
    {
        var image = new Bitmap(area.Width, area.Height, PixelFormat.Format24bppRgb);
        try
        {
            using (var graphics = Graphics.FromImage(image))
            {
                IntPtr source = GetDC(IntPtr.Zero);
                if (source == IntPtr.Zero) throw new InvalidOperationException("Could not access the screen.");
                try
                {
                    var context = graphics.GetHdc();
                    try
                    {
                        if (!BitBlt(context, 0, 0, area.Width, area.Height, source, area.Left, area.Top, 0x40CC0020))
                            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                    }
                    finally { graphics.ReleaseHdc(context); }
                }
                finally { ReleaseDC(IntPtr.Zero, source); }
            }
            return image;
        }
        catch
        {
            image.Dispose();
            throw;
        }
    }
}
