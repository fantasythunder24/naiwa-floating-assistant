using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Windows.Forms;

internal sealed class FloatingChatApplication : ApplicationContext
{
    private const int CollapsedTopInset = 96;
    private readonly LauncherButton launcher;
    private readonly Timer timer;
    private IntPtr main;
    private IntPtr floatingWindow;
    private ScreenshotDock dock;
    private HashSet<IntPtr> existingWindows;
    private DateTime openDeadline;
    private bool checkingNewWindow;
    private IntPtr candidate;
    private DateTime candidateReadyAfter;
    private bool expectComposer;
    private string sourceTitle;

    internal FloatingChatApplication()
    {
        launcher = new LauncherButton(OpenFloatingChat, ExitThread);
        timer = new Timer { Interval = 125 };
        timer.Tick += delegate { FollowCodex(); };
        timer.Start();
    }

    private void FollowCodex()
    {
        var foreground = Native.GetForegroundWindow();
        if (main == IntPtr.Zero || !ChatWindow.IsCodexWindow(main))
        {
            if (foreground != floatingWindow && ChatWindow.IsCodexWindow(foreground)) main = foreground;
            else main = ChatWindow.Windows().FirstOrDefault(window => window != floatingWindow && !Native.IsIconic(window));
        }

        timer.Interval = main == IntPtr.Zero ? 500 : 125;
        if (existingWindows != null && !checkingNewWindow) FinishOpeningWindow();
        var show = main != IntPtr.Zero && main == Native.GetForegroundWindow() && !Native.IsIconic(main);
        if (show) launcher.ShowAt(main);
        else if (!launcher.MenuOpen) launcher.Hide();
    }

    private async void OpenFloatingChat()
    {
        if (existingWindows != null || !ChatWindow.IsCodexWindow(main) || Native.IsIconic(main)) return;
        if (dock != null && !dock.IsDisposed)
        {
            dock.OpenChat();
            return;
        }

        existingWindows = new HashSet<IntPtr>(ChatWindow.Windows());
        existingWindows.Add(main);
        openDeadline = DateTime.UtcNow.AddSeconds(9);
        checkingNewWindow = true;
        launcher.SetOpening(true);
        try
        {
            if (Native.GetForegroundWindow() != main) Native.SetForegroundWindow(main);
            var origin = main;
            var result = await Task.Run(delegate
            {
                bool hasComposer = ChatWindow.HasComposer(origin);
                string title = ChatWindow.GetChatTitle(origin);
                bool opened = ChatWindow.OpenInNewWindow(origin);
                return new { HasComposer = hasComposer, Title = title, Opened = opened };
            });
            expectComposer = result.HasComposer;
            sourceTitle = result.Title;
            if (result.Opened)
            {
                openDeadline = DateTime.UtcNow.AddSeconds(9);
                return;
            }
        }
        catch (ElementNotAvailableException) { }
        catch (InvalidOperationException) { }
        catch (COMException) { }
        finally { checkingNewWindow = false; }
        openDeadline = DateTime.UtcNow.AddSeconds(3);
    }

    private void FinishOpeningWindow()
    {
        var now = DateTime.UtcNow;
        var added = ChatWindow.Windows().Where(window => !existingWindows.Contains(window)).ToArray();
        if (added.Length == 1)
        {
            if (candidate != added[0])
            {
                candidate = added[0];
                candidateReadyAfter = now.AddMilliseconds(500);
                return;
            }
            if (now < candidateReadyAfter) return;
            if (expectComposer || sourceTitle != null)
            {
                checkingNewWindow = true;
                bool ready;
                string title;
                try
                {
                    ready = ChatWindow.HasComposer(candidate);
                    title = sourceTitle == null ? null : ChatWindow.GetChatTitle(candidate);
                }
                finally { checkingNewWindow = false; }
                if (title != null && title != sourceTitle)
                {
                    if (now >= openDeadline) StopOpening("请回到要打开的会话，再点击「置顶浮窗」。");
                    return;
                }
                if ((!ready || (sourceTitle != null && title == null)) && now < openDeadline) return;
            }
            AttachFloatingWindow(added[0]);
        }
        else if (added.Length > 1 || now >= openDeadline)
        {
            StopOpening("没有识别到新增的聊天窗口，请重试。");
        }
    }

    private void AttachFloatingWindow(IntPtr window)
    {
        if (window == main || !ChatWindow.IsCodexWindow(window))
        {
            StopOpening("请回到主窗口后重试。");
            return;
        }
        floatingWindow = window;
        StopOpening(null);
        Native.PlaceFloatingWindow(window, main, CollapsedTopInset);
        dock = new ScreenshotDock(window, CollapsedTopInset);
        dock.CaptureStarting += launcher.Hide;
        dock.FormClosed += delegate { dock = null; floatingWindow = IntPtr.Zero; };
        dock.Show();
    }

    private void StopOpening(string message)
    {
        existingWindows = null;
        candidate = IntPtr.Zero;
        sourceTitle = null;
        launcher.SetOpening(false);
        if (message != null) launcher.ShowStatus(message);
    }

    protected override void ExitThreadCore()
    {
        timer.Stop();
        if (dock != null) dock.Close();
        launcher.Close();
        base.ExitThreadCore();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            launcher.Dispose();
            if (dock != null) dock.Dispose();
        }
        base.Dispose(disposing);
    }
}

internal sealed class LauncherButton : Form
{
    private const string IdleLabel = "置顶浮窗";
    private readonly RoundImageButton open;
    private readonly ToolTip tip;
    private readonly ContextMenuStrip menu;

    internal LauncherButton(Action onOpen, Action onQuit)
    {
        Text = "Codex 浮窗入口";
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        AutoScaleMode = AutoScaleMode.None;
        ShowInTaskbar = false;
        TopMost = true;

        open = new RoundImageButton(IdleLabel, "pin.png") { Dock = DockStyle.Fill };
        BackColor = open.BackColor;
        open.Click += delegate { BeginInvoke(onOpen); };
        Controls.Add(open);

        menu = new ContextMenuStrip();
        menu.Items.Add("退出浮窗助手", null, delegate { onQuit(); });
        open.ContextMenuStrip = menu;
        tip = new ToolTip();
        tip.SetToolTip(open, "单独打开当前会话的截图浮窗");
    }

    internal bool MenuOpen { get { return menu.Visible; } }

    protected override bool ShowWithoutActivation { get { return true; } }

    protected override void OnSizeChanged(EventArgs args)
    {
        base.OnSizeChanged(args);
        RoundedWindow.ApplyRegion(this, Math.Min(ClientSize.Width, ClientSize.Height) / 2);
    }

    protected override CreateParams CreateParams
    {
        get
        {
            var parameters = base.CreateParams;
            parameters.ExStyle |= 0x08000000 | 0x00000080; // WS_EX_NOACTIVATE and WS_EX_TOOLWINDOW
            return parameters;
        }
    }

    internal void ShowAt(IntPtr main)
    {
        Native.Rect rect;
        if (!Native.GetVisibleBounds(main, out rect)) return;
        double scale = Math.Max(96u, Native.GetDpiForWindow(main)) / 96.0;
        var diameter = (int)Math.Round(46 * scale);
        var captionButtons = (int)Math.Round(146 * scale);
        var padding = (int)Math.Round(4 * scale);
        var bounds = new Rectangle(rect.Right - captionButtons - diameter, rect.Top + padding, diameter, diameter);
        if (Bounds != bounds) Bounds = bounds;
        if (!Visible) Show();
    }

    internal void SetOpening(bool opening)
    {
        open.Text = opening ? "正在开窗" : IdleLabel;
        open.Enabled = !opening;
    }

    internal void ShowStatus(string message)
    {
        tip.Show(message, open, 0, open.Height + 3, 3500);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            if (tip != null) tip.Dispose();
            if (menu != null) menu.Dispose();
        }
        base.Dispose(disposing);
    }
}
