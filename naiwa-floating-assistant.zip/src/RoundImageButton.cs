using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Reflection;
using System.Windows.Forms;

internal sealed class RoundImageButton : Button
{
    private readonly Bitmap artwork;
    private Color? accent;
    private bool hovering;
    private bool pressed;

    internal RoundImageButton(string label, string imageName)
    {
        Text = label;
        AccessibleName = label;
        Cursor = Cursors.Hand;
        TabStop = false;
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        BackColor = Color.FromArgb(22, 37, 46);
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);

        using (var source = Assembly.GetExecutingAssembly().GetManifestResourceStream("CodexFloat." + imageName))
        using (var image = Image.FromStream(source))
            artwork = new Bitmap(image);
    }

    internal Color? Accent
    {
        set
        {
            if (accent == value) return;
            accent = value;
            Invalidate();
        }
    }

    protected override void OnSizeChanged(EventArgs args)
    {
        base.OnSizeChanged(args);
        RoundedWindow.ApplyRegion(this, Math.Min(Width, Height) / 2);
    }

    protected override void OnPaint(PaintEventArgs args)
    {
        if (Width < 6 || Height < 6 || artwork == null) return;
        var graphics = args.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

        float edge = Math.Max(1f, Width / 49f);
        var circle = new RectangleF(edge / 2, edge / 2, Width - edge, Height - edge);
        var top = hovering && Enabled ? Color.FromArgb(64, 98, 99) : Color.FromArgb(46, 75, 80);
        var bottom = Color.FromArgb(21, 40, 50);
        using (var fill = new LinearGradientBrush(circle, top, bottom, LinearGradientMode.Vertical))
            graphics.FillEllipse(fill, circle);

        int inset = Math.Max(1, Width / 25) + (pressed && Enabled ? Math.Max(1, Width / 34) : 0);
        var imageBounds = new Rectangle(inset, inset, Width - 2 * inset, Height - 2 * inset);
        using (var mask = new GraphicsPath())
        using (var attributes = new ImageAttributes())
        {
            var previous = graphics.Save();
            mask.AddEllipse(circle);
            graphics.SetClip(mask, CombineMode.Intersect);
            attributes.SetWrapMode(WrapMode.TileFlipXY);
            if (!Enabled) attributes.SetColorMatrix(new ColorMatrix { Matrix33 = 0.58f });
            graphics.DrawImage(artwork, imageBounds, 0, 0, artwork.Width, artwork.Height, GraphicsUnit.Pixel, attributes);
            graphics.Restore(previous);
        }

        var border = accent ?? (hovering && Enabled ? Color.FromArgb(231, 222, 177) : Color.FromArgb(151, 176, 174));
        using (var pen = new Pen(border, accent.HasValue ? edge * 1.7f : edge))
            graphics.DrawEllipse(pen, circle);
    }

    protected override void OnMouseEnter(EventArgs args)
    {
        base.OnMouseEnter(args);
        hovering = true;
        Invalidate();
    }

    protected override void OnMouseLeave(EventArgs args)
    {
        base.OnMouseLeave(args);
        hovering = false;
        Invalidate();
    }

    protected override void OnMouseDown(MouseEventArgs args)
    {
        base.OnMouseDown(args);
        pressed = args.Button == MouseButtons.Left;
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs args)
    {
        base.OnMouseUp(args);
        pressed = false;
        Invalidate();
    }

    protected override void OnMouseCaptureChanged(EventArgs args)
    {
        base.OnMouseCaptureChanged(args);
        if (!Capture && pressed)
        {
            pressed = false;
            Invalidate();
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && artwork != null) artwork.Dispose();
        base.Dispose(disposing);
    }
}

internal static class RoundedWindow
{
    internal static void ApplyRegion(Control control, int radius)
    {
        if (control.Width < 2 || control.Height < 2 || radius < 1) return;
        var width = control.Width;
        var height = control.Height;
        var diameter = Math.Min(2 * radius, Math.Min(width, height));
        using (var path = new GraphicsPath())
        {
            if (width == height && diameter >= width - 1) path.AddEllipse(0, 0, width, height);
            else
            {
                path.AddArc(0, 0, diameter, diameter, 180, 90);
                path.AddArc(width - diameter, 0, diameter, diameter, 270, 90);
                path.AddArc(width - diameter, height - diameter, diameter, diameter, 0, 90);
                path.AddArc(0, height - diameter, diameter, diameter, 90, 90);
                path.CloseFigure();
            }
            var old = control.Region;
            control.Region = new Region(path);
            if (old != null) old.Dispose();
        }
    }
}
